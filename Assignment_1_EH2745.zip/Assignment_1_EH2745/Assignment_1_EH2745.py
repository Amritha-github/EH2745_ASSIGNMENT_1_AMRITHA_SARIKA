# -*- coding: utf-8 -*-
"""
#Assignment 1 combines Python programming, CIM-XML modelling and parsing and
finally model building using Pandapower and using these create an embryo of Energy Management
System.

@author: Amritha Jayan and Sarika Vaiyapuri Gunassekaran

"""
import xml.etree.ElementTree as ET
import numpy as np

import pandapower.networks
import pandapower as pp
import pandapower.plotting as plot
import matplotlib

import pandapower.networks
import pandapower as pp

from tkinter import *
from tkinter import ttk
import tkinter
from tkinter import filedialog

# GUI of the application
root = Tk()
root.title("EH2745 - Assignment 1")
content = ttk.Frame(root)
frame = ttk.Frame(content, borderwidth=5, relief="solid", width=600, height=300)
img = PhotoImage(file='KTH.png')
panel = ttk.Label(content, image=img)
content.grid(column=1, row=0)
frame.grid(column=1, row=0, columnspan=3, rowspan=2)
panel.grid(column=1, row=0, columnspan=3, rowspan=2)

# Insert File
def EQ_file():
    EQ_file = filedialog.askopenfilename()
    global EQ_file_XML, Message_EQ
    EQ_file_XML = EQ_file
    Message_EQ = "Added EQ File"

def SSH_file():
    SSH_file = filedialog.askopenfilename()
    global SSH_file_XML, Message_SSQ
    SSH_file_XML = SSH_file
    Message_SSH = "Added SSH File"

# GUI Layout
Button_EQ = Button(root, text="Select EQ File", command=EQ_file)
Button_EQ.grid(column=1, row=3, sticky='nesw')
Button_SSH = Button(root, text="Select SSH File", command=SSH_file)
Button_SSH.grid(column=1, row=4, sticky='nesw')
Button_Run = Button(root, text="Run", command=root.destroy)
Button_Run.grid(column=1, row=5,sticky='nesw')

root.mainloop()

# Parse the XML files
tree_EQ = ET.parse(EQ_file_XML)
tree_SSH = ET.parse(SSH_file_XML)

# Get the root of the parsed trees
root_EQ = tree_EQ.getroot()
root_SSH = tree_SSH.getroot()

# Define the namespaces used in the XML files
ns = {
    'cim': 'http://iec.ch/TC57/2013/CIM-schema-cim16#',
    'entsoe': 'http://entsoe.eu/CIM/SchemaExtension/3/1#',
    'md': 'http://iec.ch/TC57/61970-552/ModelDescription/1#',
    'rdf': '{http://www.w3.org/1999/02/22-rdf-syntax-ns#}'}

# Import the required classes from their respective modules
from Classes.GeneratingUnit import GeneratingUnit
from Classes.ACLineSegment import ACLineSegment
from Classes.BusbarSection import BusbarSection
from Classes.Breaker import Breaker
from Classes.PowerTransformer import PowerTransformer
from Classes.PowerTransformerEnd import PowerTransformerEnd
from Classes.RatioTapChanger import RatioTapChanger
from Classes.EnergyConsumer import EnergyConsumer
from Classes.LinearShuntCompensator import LinearShuntCompensator
from Classes.SynchronousMachine import SynchronousMachine
from Classes.BaseVoltage import BaseVoltage
from Classes.VoltageLevel import VoltageLevel
from Classes.RegulatingControl import RegulatingControl
from Classes.ConductingEquipment import ConductingEquipment
from Classes.ConnectivityNode import ConnectivityNode
from Classes.Terminal import Terminal

# Initialize empty lists to store the extracted information from the EQ XML files
ACLine_Segment_length = []
ACLine_Segment_list = []
ACLine_Segment_name = []
BaseVoltage_list = []
Breaker_list = []
BusbarSection_list = []
ConnectivityNode_list = []
ConnectivityNode_list_id = []
EnergyConsumer_list = []
GeneratingUnit_list = []
LinearShuntCompensator_list = []
Object_name_list = []
PowerTransformer_list = []
PowerTransformerEnd_list = []
RatioTapChanger_list = []
RegulatingControl_list = []
SynchronousMachine_list = []
Terminal_list = []
Terminal_list_ConductingEquipment = []
Terminal_list_ConnectivityNode = []
VoltageLevel_list = []
node_list = []

# Initialize empty lists to store the extracted information from the SSH XML files
Breaker_list_ssh = []
EnergyConsumer_list_ssh = []
Object_name_list_2 = []
RatioTapChanger_list_ssh = []
Terminal_list_ssh = []

# Loop through the root_EQ list of equipment to mapping the attributes to the corresponding attributes
# of the class and extract relevant data from the EQ XML file.
for equipment in root_EQ:
    if ns['cim'] in equipment.tag:
        name = equipment.tag.replace("{"+ns['cim']+"}", "")
        Object_name_list.append(name)
        # Check the type of equipment and create an instance of the corresponding class
        if name == 'BusbarSection':
            busbar_section = BusbarSection(equipment)
            busbar_section.name = equipment.find('cim:IdentifiedObject.name', ns).text
            busbar_section.id = equipment.attrib.get(ns['rdf']+'ID')
            busbar_section.EquipmentContainer = equipment.find('cim:Equipment.EquipmentContainer', ns).attrib.get(ns['rdf']+'resource').replace('#', '')
            BusbarSection_list.append(busbar_section)
            busbar_section.CE_type = 'BusbarSection'

        elif name == 'ACLineSegment':
            ac_line_segment = ACLineSegment(equipment)
            ac_line_segment.name = equipment.find('cim:IdentifiedObject.name', ns).text
            ac_line_segment.id = equipment.attrib.get(ns['rdf']+'ID')
            ac_line_segment.name = equipment.find('cim:IdentifiedObject.name', ns).text
            ac_line_segment.r = equipment.find('cim:ACLineSegment.r', ns).text
            ac_line_segment.x = equipment.find('cim:ACLineSegment.x', ns).text
            ac_line_segment.bch = equipment.find('cim:ACLineSegment.bch', ns).text
            ac_line_segment.length = equipment.find('cim:Conductor.length', ns).text
            ACLine_Segment_list .append(ac_line_segment)

        elif name == 'Breaker':
            breaker = Breaker(equipment)
            breaker.id = equipment.attrib.get(ns['rdf']+'ID')
            breaker.state= equipment.find('cim:Switch.normalOpen', ns).text
            breaker.EquipmentContainer = equipment.find('cim:Equipment.EquipmentContainer', ns).attrib.get(ns['rdf']+'resource').replace('#', '')
            Breaker_list.append(breaker)


        elif name == 'EnergyConsumer':
            energy_consumer = EnergyConsumer(equipment)
            energy_consumer.name = equipment.find('cim:IdentifiedObject.name', ns).text
            energy_consumer.id = equipment.attrib.get(ns['rdf']+'ID')
            energy_consumer.aggregate = equipment.find('cim:Equipment.aggregate', ns).text
            energy_consumer.EquipmentContainer = equipment.find('cim:Equipment.EquipmentContainer', ns).attrib.get(ns['rdf']+'resource').replace('#', '')
            EnergyConsumer_list.append(energy_consumer)

        elif name == 'GeneratingUnit':
            generating_unit = GeneratingUnit(equipment)
            generating_unit.name = equipment.find('cim:IdentifiedObject.name', ns).text
            generating_unit.id = equipment.attrib.get(ns['rdf']+'ID')
            generating_unit.initialP = equipment.find('cim:GeneratingUnit.initialP', ns).text
            generating_unit.nominalP = equipment.find('cim:GeneratingUnit.nominalP', ns).text
            generating_unit.maxOperatingP = equipment.find('cim:GeneratingUnit.maxOperatingP', ns).text
            generating_unit.minOperatingP = equipment.find('cim:GeneratingUnit.minOperatingP', ns).text
            generating_unit.container_id = equipment.find('cim:Equipment.EquipmentContainer', ns).attrib.get(ns['rdf']+'resource').replace('#', '')
            GeneratingUnit_list.append(generating_unit)

        elif name == 'LinearShuntCompensator':
            linear_shunt_compensator = LinearShuntCompensator(equipment)
            linear_shunt_compensator.name = equipment.find('cim:IdentifiedObject.name', ns).text
            linear_shunt_compensator.id = equipment.attrib.get(ns['rdf']+'ID')
            linear_shunt_compensator.container_id = equipment.find('cim:Equipment.EquipmentContainer', ns).attrib.get(ns['rdf']+'resource').replace('#', '')
            linear_shunt_compensator.RegulatingControl = equipment.find('cim:RegulatingCondEq.RegulatingControl', ns).attrib.get(ns['rdf']+'resource')
            linear_shunt_compensator.nomU = float(equipment.find('cim:ShuntCompensator.nomU', ns).text)
            linear_shunt_compensator.b = float(equipment.find('cim:LinearShuntCompensator.bPerSection', ns).text)
            linear_shunt_compensator.q = float(linear_shunt_compensator.b*linear_shunt_compensator.nomU*linear_shunt_compensator.nomU)
            LinearShuntCompensator_list.append(linear_shunt_compensator)

        elif name == 'VoltageLevel':
            voltage_level = VoltageLevel(equipment)
            voltage_level.name = equipment.find('cim:IdentifiedObject.name', ns).text
            voltage_level.id = equipment.attrib.get(ns['rdf']+'ID')
            voltage_level.lowVoltageLimit = equipment.find('cim:VoltageLevel.lowVoltageLimit', ns).text
            voltage_level.highVoltageLimit = equipment.find('cim:VoltageLevel.highVoltageLimit', ns).text
            voltage_level.Substation = equipment.find('cim:VoltageLevel.Substation', ns).attrib.get(ns['rdf']+'resource')
            voltage_level.BaseVoltage = equipment.find('cim:VoltageLevel.BaseVoltage', ns).attrib.get(ns['rdf']+'resource').replace('#', '')
            VoltageLevel_list.append(voltage_level)

        elif name == 'PowerTransformer':
            power_transformer = PowerTransformer(equipment)
            power_transformer.name = equipment.find('cim:IdentifiedObject.name', ns).text
            power_transformer.id = equipment.attrib.get(ns['rdf']+'ID')
            power_transformer.EquipmentContainer = equipment.find('cim:Equipment.EquipmentContainer', ns).attrib.get(ns['rdf']+'resource').replace('#', '')
            PowerTransformer_list.append(power_transformer)
            
        elif name == 'PowerTransformerEnd':
            power_transformer_end = PowerTransformerEnd(equipment)
            power_transformer_end.id=equipment.attrib.get(ns['rdf']+'ID'),
            power_transformer_end.name=equipment.find('cim:IdentifiedObject.name', ns).text
            power_transformer_end.r=float(equipment.find('cim:PowerTransformerEnd.r', ns).text)
            power_transformer_end.x=float(equipment.find('cim:PowerTransformerEnd.x', ns).text)
            power_transformer_end.b=float(equipment.find('cim:PowerTransformerEnd.b', ns).text)
            power_transformer_end.g=float(equipment.find('cim:PowerTransformerEnd.g', ns).text)
            power_transformer_end.r0=float(equipment.find('cim:PowerTransformerEnd.r0', ns).text)
            power_transformer_end.x0=float(equipment.find('cim:PowerTransformerEnd.x0', ns).text)
            power_transformer_end.b0=float(equipment.find('cim:PowerTransformerEnd.b0', ns).text)
            power_transformer_end.g0=float(equipment.find('cim:PowerTransformerEnd.g0', ns).text)
            power_transformer_end.rground=float(equipment.find('cim:TransformerEnd.rground', ns).text)
            power_transformer_end.xground=float(equipment.find('cim:TransformerEnd.xground', ns).text)
            power_transformer_end.ratedS=float(equipment.find('cim:PowerTransformerEnd.ratedS', ns).text)
            power_transformer_end.ratedU=float(equipment.find('cim:PowerTransformerEnd.ratedU', ns).text)
            power_transformer_end.phaseAngleClock=float(equipment.find('cim:PowerTransformerEnd.phaseAngleClock', ns).text)
            power_transformer_end.connectionKind=equipment.find('cim:PowerTransformerEnd.connectionKind', ns).attrib.get(ns['rdf']+'resource').replace('#', '')
            power_transformer_end.BaseVoltage=equipment.find('cim:TransformerEnd.BaseVoltage', ns).attrib.get(ns['rdf']+'resource').replace('#', '')
            power_transformer_end.PowerTransformer=equipment.find('cim:PowerTransformerEnd.PowerTransformer', ns).attrib.get(ns['rdf']+'resource').replace('#', '')
            power_transformer_end.Terminal=equipment.find('cim:TransformerEnd.Terminal', ns).attrib.get(ns['rdf']+'resource').replace('#', '')

            # Append the newly created PowerTransformerEnd object to the PowerTransformerEnd_list
            PowerTransformerEnd_list.append(power_transformer_end)
                    
        elif name == 'RatioTapChanger':
            ratio_tapchanger = RatioTapChanger(equipment)
            ratio_tapchanger.name = equipment.find('cim:IdentifiedObject.name', ns).text
            ratio_tapchanger.id = equipment.attrib.get(ns['rdf']+'ID')
            ratio_tapchanger.TapChangerControl = equipment.find('cim:TapChanger.TapChangerControl', ns).attrib.get(ns['rdf']+'resource')
            ratio_tapchanger.neutralU = equipment.find('cim:TapChanger.neutralU', ns).text
            ratio_tapchanger.lowStep = equipment.find('cim:TapChanger.lowStep', ns).text
            ratio_tapchanger.highStep = equipment.find('cim:TapChanger.highStep', ns).text
            ratio_tapchanger.neutralStep = equipment.find('cim:TapChanger.neutralStep', ns).text
            ratio_tapchanger.normalStep = equipment.find('cim:TapChanger.normalStep', ns).text
            ratio_tapchanger.stepVoltageIncrement = equipment.find('cim:RatioTapChanger.stepVoltageIncrement', ns).text
            RatioTapChanger_list.append(ratio_tapchanger)

        elif name == 'SynchronousMachine':
            synchronous_machine = SynchronousMachine(equipment)
            synchronous_machine.name = equipment.find('cim:IdentifiedObject.name', ns).text
            synchronous_machine.id = equipment.attrib.get(ns['rdf']+'ID')
            synchronous_machine.EquipmentContainer = equipment.find('cim:Equipment.EquipmentContainer', ns).attrib.get(ns['rdf']+'resource').replace('#', '')
            synchronous_machine.GeneratingUnit = equipment.find('cim:RotatingMachine.GeneratingUnit', ns).attrib.get(ns['rdf']+'resource')
            synchronous_machine.ratedU = equipment.find('cim:RotatingMachine.ratedU', ns).text
            
            i = 0
            for equipment in root_SSH:
                if ns['cim'] in equipment.tag:
                    name = equipment.tag.replace("{"+ns['cim']+"}", "")
                    if name == 'SynchronousMachine':
                        synchronous_machine = SynchronousMachine(equipment)
                        synchronous_machine.active_power = equipment.find('cim:RotatingMachine.p', ns).text
                        synchronous_machine.reactive_power = equipment.find('cim:RotatingMachine.q', ns).text
                        i += 1
                        
            SynchronousMachine_list.append(synchronous_machine)

        elif name == 'BaseVoltage':
            base_voltage = BaseVoltage(equipment)
            base_voltage.name = equipment.find('cim:IdentifiedObject.name', ns).text
            base_voltage.id = equipment.attrib.get(ns['rdf']+'ID')
            BaseVoltage_list.append(base_voltage)
            base_voltage.nominalVoltage = equipment.find('cim:BaseVoltage.nominalVoltage', ns).text

        elif name == 'ConnectivityNode':
            connectivity_node = ConnectivityNode(equipment)
            connectivity_node.name = equipment.find('cim:IdentifiedObject.name', ns).text
            connectivity_node.id = equipment.attrib.get(ns['rdf']+'ID')
            connectivity_node.container_id = equipment.find('cim:ConnectivityNode.ConnectivityNodeContainer', ns).attrib.get(ns['rdf']+'resource').replace('#', '')
            ConnectivityNode_list.append(connectivity_node)
            ConnectivityNode_list_id.append(connectivity_node.id)

        elif name == 'Terminal':
            terminal_obj = Terminal(equipment)
            terminal_obj.name = equipment.find('cim:IdentifiedObject.name', ns).text
            terminal_obj.id = equipment.attrib.get(ns['rdf']+'ID')
            terminal_obj.ConductingEquipment = equipment.find('cim:Terminal.ConductingEquipment', ns).attrib.get(ns['rdf']+'resource').replace('#', '')
            terminal_obj.ConnectivityNode = equipment.find('cim:Terminal.ConnectivityNode', ns).attrib.get(ns['rdf']+'resource').replace('#', '')
            terminal_obj.traversal_flag = 0
            Terminal_list.append(terminal_obj)
            Terminal_list_ConductingEquipment.append(
                terminal_obj.ConductingEquipment.replace('#', ''))
            Terminal_list_ConnectivityNode.append(
                terminal_obj.ConnectivityNode.replace('#', ''))


# Loop through the root_EQ list of equipment to mapping the attributes to the corresponding attributes
# of your class and extract relevant data from the SSH XML file.
for equipment in root_SSH:
    if ns['cim'] in equipment.tag:
        name = equipment.tag.replace("{"+ns['cim']+"}", "")
        Object_name_list_2.append(name)
        if name == 'Terminal':
            terminal_obj = Terminal(equipment)
            terminal_obj.id = equipment.attrib.get(ns['rdf']+'ID')
            Terminal_list_ssh.append(terminal_obj)

        elif name == 'EnergyConsumer':
            energy_consumer = EnergyConsumer(equipment)
            energy_consumer.id = equipment.attrib.get(ns['rdf']+'ID')
            energy_consumer.p = equipment.find('cim:EnergyConsumer.p', ns).text
            energy_consumer.q = equipment.find('cim:EnergyConsumer.q', ns).text
            EnergyConsumer_list_ssh.append(energy_consumer.p)
            
        elif name == 'RatioTapChanger':
            ratio_tapchanger = RatioTapChanger(equipment)
            ratio_tapchanger.id = equipment.attrib.get(ns['rdf']+'ID')
            ratio_tapchanger.step = equipment.find('cim:TapChanger.step', ns).text
            ratio_tapchanger.controlEnabled = equipment.find('cim:TapChanger.controlEnabled', ns).text
            RatioTapChanger_list_ssh.append(ratio_tapchanger)

        elif name == 'Breaker':
            breaker = Breaker(equipment)
            breaker.id = equipment.attrib.get(ns['rdf']+'ID')
            breaker.Switch = equipment.find('cim:Switch.open', ns).text
            Breaker_list_ssh.append(breaker)

# Network Travsersing

# Dictionary for indexing the IDs
Terminal_dic = {}
for i in range(len(Terminal_list)):
    Terminal_dic[Terminal_list[i].id] = i 
    
ConnectivityNode_dic = {}
for i in range(len(ConnectivityNode_list)):
    ConnectivityNode_dic[ConnectivityNode_list[i].id] = i  
    
VoltageLevel_dic = {}
for i in range(len(VoltageLevel_list)):
    VoltageLevel_dic[VoltageLevel_list[i].id] = i 
    
    
# Define function to find the busbar for connectivit node attached to terminal

def find_busbar_for_connectivity_node(CN_id):
    type_cn = 'n'
    for i in range(len(Terminal_list)):
        if CN_id == Terminal_list[i].ConnectivityNode:
            for j in range(len(BusbarSection_list)):
                if Terminal_list[i].ConductingEquipment == BusbarSection_list[j].id:
                    type_cn ='b'
    return type_cn
       
#Traversal for each equipment

#Connectivity Node
connectivity_node_ = [[0 for i in range(3)] for j in range(len(ConnectivityNode_list))]
for i in range(len(ConnectivityNode_list)):
    connectivity_node_[i][0] = ConnectivityNode_list[i].name
    v = VoltageLevel_dic[ConnectivityNode_list[i].container_id]
    connectivity_node_[i][1] = float(VoltageLevel_list[v].name)
    connectivity_node_[i][2] = find_busbar_for_connectivity_node(ConnectivityNode_list[i].id)

#Power Transformer
Power_Transformer_ = [[0 for i in range(8)] for j in range(len(PowerTransformer_list))]
for i in range(len(PowerTransformer_list)):
    Power_Transformer_[i][0] = PowerTransformer_list[i].name
    Power_Transformer_[i][7] = 'two_winding'
    terminal_PT = []
    Voltage_PT = []
    Connectivitynode_PT = []

    for j in range(len(PowerTransformerEnd_list)):
         if PowerTransformer_list[i].id == PowerTransformerEnd_list[j].PowerTransformer:
             terminal_PT.append(Terminal_dic[PowerTransformerEnd_list[j].Terminal])
             Connectivitynode_PT.append(ConnectivityNode_dic[Terminal_list[terminal_PT[-1]].ConnectivityNode])
             Voltage_PT.append(connectivity_node_[Connectivitynode_PT[-1]][1])

    min_Voltage_PT = Voltage_PT.index(min(Voltage_PT))
    max_Voltage_PT = Voltage_PT.index(max(Voltage_PT))

    Power_Transformer_[i][1] = Connectivitynode_PT[min_Voltage_PT]
    Power_Transformer_[i][4] = Voltage_PT[min_Voltage_PT]
    Power_Transformer_[i][3] = Connectivitynode_PT[max_Voltage_PT]
    Power_Transformer_[i][6] = Voltage_PT[max_Voltage_PT]

    if len(Connectivitynode_PT) == 3:
        Power_Transformer_[i][2] = Connectivitynode_PT[3 - (min_Voltage_PT + max_Voltage_PT)]
        Power_Transformer_[i][5] = Voltage_PT[3 - (min_Voltage_PT + max_Voltage_PT)]
        Power_Transformer_[i][7] = 'three_winding'

#Line
AC_Line_ = [[0 for i in range(4)] for j in range(len(ACLine_Segment_list ))]
for i in range(len(ACLine_Segment_list )):
    AC_Line_[i][0] = ACLine_Segment_list [i].name
    AC_Line_[i][3] = float(ACLine_Segment_list[i].length)
    
    count = 0
    for j in range(len(Terminal_list)):
        if ACLine_Segment_list [i].id == Terminal_list[j].ConductingEquipment:
            count += 1
            if count == 1:
                AC_Line_[i][1] = ConnectivityNode_dic[Terminal_list[j].ConnectivityNode]
            else:
                AC_Line_[i][2] = ConnectivityNode_dic[Terminal_list[j].ConnectivityNode]

#Breaker
Breaker_t = [[0 for i in range(4)] for j in range(len(Breaker_list))]
for i in range(len(Breaker_list)):
    Breaker_t[i][0] = Breaker_list[i].name
    if Breaker_list[i].state == 'false':
        Breaker_t[i][3] = True
    
    count = 0
    for j in range(len(Terminal_list)):
        if Breaker_list[i].id == Terminal_list[j].ConductingEquipment:
            count += 1
            if count == 1:
                Breaker_t[i][1] = ConnectivityNode_dic[Terminal_list[j].ConnectivityNode]
            else:
                Breaker_t[i][2] = ConnectivityNode_dic[Terminal_list[j].ConnectivityNode]
  
#EnergyConsumer
EnergyConsumer_ = [[0 for i in range(4)] for j in range(len(EnergyConsumer_list))]
for i in range(len(EnergyConsumer_list)):
    EnergyConsumer_[i][0] = EnergyConsumer_list[i].name
    EnergyConsumer_[i][2] = EnergyConsumer_list[i].p
    EnergyConsumer_[i][3] = EnergyConsumer_list[i].q
    
    for j in range(len(Terminal_list)):
        if EnergyConsumer_list[i].id == Terminal_list[j].ConductingEquipment:
            EnergyConsumer_[i][1] = ConnectivityNode_dic[Terminal_list[j].ConnectivityNode]

#Generator
Generator_ = [[0 for i in range(3)] for j in range(len(GeneratingUnit_list))]
for i in range(len(GeneratingUnit_list)):
    Generator_[i][0] = GeneratingUnit_list[i].name
    Generator_[i][2] = GeneratingUnit_list[i].nominalP
    
    for j in range(len(Terminal_list)):
        if GeneratingUnit_list[i].id == Terminal_list[j].ConductingEquipment:
            Generator_[i][1] = ConnectivityNode_dic[Terminal_list[j].ConnectivityNode]

#syncronous motor
SyncronousMachine_ = [[0 for i in range(3)] for j in range(len(SynchronousMachine_list))]
for i in range(len(SynchronousMachine_list)):
    SyncronousMachine_[i][0] = SynchronousMachine_list[i].name
    SyncronousMachine_[i][2] = SynchronousMachine_list[i].active_power
    
    for j in range(len(Terminal_list)):
        if SynchronousMachine_list[i].id == Terminal_list[j].ConductingEquipment:
            SyncronousMachine_[i][1] = ConnectivityNode_dic[Terminal_list[j].ConnectivityNode]
 
#Create network in Pandapower.

# create component for panda power
net = pp.create_empty_network()

# create busbar 'b' and node 'n'

for i in range (len(connectivity_node_)):
    pp.create_bus(net, name=connectivity_node_[i][0], vn_kv=connectivity_node_[i][1], type = connectivity_node_[i][2])

print(net.bus)

#Transformers
for i in range (len(PowerTransformer_list)):
    if Power_Transformer_[i][7] == 'two_winding':
        pp.create_transformer (net, Power_Transformer_[i][3], Power_Transformer_[i][1], name = Power_Transformer_[i][0], std_type="25 MVA 110/20 kV")
    if Power_Transformer_[i][7] == 'three_winding':
        pp.create.create_transformer3w (net, Power_Transformer_[i][3], Power_Transformer_[i][2], Power_Transformer_[i][1], name = Power_Transformer_[i][0], std_type="63/25/38 MVA 110/20/10 kV")
print(net.trafo3w)
#Lines
for i in range (len(ACLine_Segment_list )):
    pp.create_line(net, from_bus=AC_Line_[i][1], to_bus=AC_Line_[i][2], length_km = AC_Line_[i][3], std_type = "N2XS(FL)2Y 1x300 RM/35 64/110 kV",  name = AC_Line_[i][0])
print(net.line)
#Breakers
for i in range (len(Breaker_list)):
    pp.create_switch(net, Breaker_t[i][1], Breaker_t[i][2], et="b", type="CB", closed = Breaker_t[i][3])
print(net.switch)
#Load
for i in range (len(EnergyConsumer_list)):
    pp.create_load(net, EnergyConsumer_[i][1], p_mw = EnergyConsumer_[i][2], q_mvar = EnergyConsumer_[i][3], name = EnergyConsumer_[i][0])
print(net.load)
#Generator 
for i in range (len(GeneratingUnit_list)):
    pp.create_sgen(net, Generator_[i][1], p_mw = Generator_[i][2], name = Generator_[i][0])

for i in range (len(SynchronousMachine_list)):
    pp.create_sgen(net, SyncronousMachine_[i][1], p_mw = SyncronousMachine_[i][2], name = SyncronousMachine_[i][0])
print(net.sgen)

print(net)

# plot the network
plot.simple_plot (net, line_width=3.0, bus_size=1.0, ext_grid_size=1.0,
                        trafo_size=1.0, plot_loads=True, plot_sgens=True, 
                        load_size=2.0, sgen_size=2.5, switch_size=1.0, 
                        switch_distance=1.0, plot_line_switches=True, 
                        scale_size=True, 
                        bus_color=['red' if net.bus.at[i, 'type'] == 'b' else 'blue' for i in net.bus.index], 
                        line_color='black', trafo_color='green', switch_color='k', 
                        library='igraph', show_plot=True, ax=None)