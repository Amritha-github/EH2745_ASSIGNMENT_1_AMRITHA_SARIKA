# -*- coding: utf-8 -*-
class ConnectivityNode:
    def __init__(self, name):
        self.name = name
        self.id = 'id'
        self.Node_Type = 'CN'
        self.container_id = 'container_id'
        self.Terminal_List = []
        self.Num_attachTerms=0
        self.voltage=0
        self.CE_type = 'not CE'
    

