# -*- coding: utf-8 -*-
class SynchronousMachine:
    def __init__(self, name):
        self.name = name
        self.id = 'id'
        self.GeneratingUnit ='GeneratingUnit'
        self.ratedU = 'ratedU'
        self.Terminal_List = []
        self.Node_Type = 'CE'
        self.Num_attachTerms=0
        self.CE_type='SynchronousMachine'
