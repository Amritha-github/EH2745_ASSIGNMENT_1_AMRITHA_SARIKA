# -*- coding: utf-8 -*-
class PowerTransformer:
    def __init__(self, name):
        self.name = name
        self.Terminal_list = []
        self.Num_attachTerms = 0 
        self.type = 'CE'
        self.rdf_id = 'id'
        self.CE_type='Transformer'
 