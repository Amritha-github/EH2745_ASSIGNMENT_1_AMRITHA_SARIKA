# -*- coding: utf-8 -*-
class ConductingEquipment:
    def __init__(self, name):
        self.name = name
        self.id = 'id'
        self.type = 'type'
        self.CE_type = 'CE_type'
        self.terminalList = []        
