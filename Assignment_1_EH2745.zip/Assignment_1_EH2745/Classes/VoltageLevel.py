# -*- coding: utf-8 -*-
class VoltageLevel:
    def __init__(self, name):
        self.name= name
        self.id = 'id'
        self.lowVoltageLimit= 'lowVoltageLimit'
        self.highVoltageLimit= 'highVoltageLimit'

