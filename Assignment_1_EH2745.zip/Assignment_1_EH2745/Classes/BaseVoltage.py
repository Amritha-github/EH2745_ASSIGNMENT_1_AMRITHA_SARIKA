# -*- coding: utf-8 -*-
class BaseVoltage:
    def __init__(self, name):
        self.name= name
        self.id= 'id'
        self.nominalVoltage= 'nominalVoltage'
