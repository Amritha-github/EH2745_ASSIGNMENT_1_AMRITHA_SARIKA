# -*- coding: utf-8 -*-
class RegulatingControl:
    def __init__(self,name):
        self.name = name
        self.id = 'id'
