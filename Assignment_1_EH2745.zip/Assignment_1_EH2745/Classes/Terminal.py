# -*- coding: utf-8 -*-

class Terminal:
    def __init__(self, name):
        self.name = name
        self.id = 'id'
        self.type = 'TE'
        self.ConnectivityNode = 'ConnectivityNode'
        self.ConductingEquipment = 'ConductingEquipment'
        self.Terminal_List = []
    

