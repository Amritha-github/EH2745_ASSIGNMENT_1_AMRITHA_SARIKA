# -*- coding: utf-8 -*-
class RatioTapChanger:
    def __init__(self,name):
        self.name = name
        self.id = 'id'
        self.neutralU = 'neutralU'
        self.lowStep = 'lowStep'
        self.highStep = 'highStep'
        self.neutralStep = 'neutralStep'
        self.normalStep = 'normalStep'
        self.stepVoltageIncrement = 'stepVoltageIncrement'
        self.Node_Type='CE'
        self.CE_type='TapChanger'
        self.Terminal_List=[]
        self.Num_attachTerms=0    
  
